Macros
======

* cvtext : format a large par of text (with columns)

Themes
======

* Ability to change cvcontacts order (using contactzones)
* Ability to mix theme style (load style macros)
* europass format http://europass.cedefop.europa.eu
* theme empty template


